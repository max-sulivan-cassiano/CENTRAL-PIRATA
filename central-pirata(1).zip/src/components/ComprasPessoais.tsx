import React, { useState, useMemo, useEffect } from 'react';
import { ShoppingCart, Zap, Target, TrendingUp } from 'lucide-react';

interface CompraItem {
  id: string;
  produto: string;
  precoUsd: number;
  prioridade: string;
}

export default function ComprasPessoais() {
  const CAMBIO = 5.20;
  const COTA = 500;

  const [items, setItems] = useState<CompraItem[]>([
    { id: '1', produto: 'Poco X8 Pro Max (512GB)', precoUsd: 505, prioridade: 'Alta (1ª Viagem)' },
    { id: '2', produto: 'Xiaomi Watch 2 Pro Black', precoUsd: 170, prioridade: 'Alta (1ª Viagem)' },
    { id: '3', produto: 'Anker 737 (140W / 24K)', precoUsd: 115, prioridade: 'Alta (1ª Viagem)' },
    { id: '4', produto: 'MacBook Air M1 (Open Box) 8/256', precoUsd: 580, prioridade: 'Alta (2ª Viagem)' },
    { id: '5', produto: 'MacBook Air M1 (Open Box) 16/512', precoUsd: 670, prioridade: 'Alta (2ª Viagem)' },
    { id: '6', produto: 'Baseus Blade (100W / 20K)', precoUsd: 75, prioridade: 'Média' },
    { id: '7', produto: 'Capa Thule Gauntlet', precoUsd: 50, prioridade: 'Alta (2ª Viagem)' }
  ]);

  const [estrategia, setEstrategia] = useState('Missão de compras pessoais: Priorizar eletrônicos essenciais conforme disponibilidade e viagem planejada.');

  const calculatedItems = useMemo(() => {
    return items.map(item => {
      const preco = item.precoUsd || 0;
      const impostoUsd = preco > COTA ? (preco - COTA) * 0.50 : 0;
      const totalBrl = (preco + impostoUsd) * CAMBIO;
      return { ...item, impostoUsd, totalBrl };
    });
  }, [items]);

  const totalGeral = useMemo(() => {
    return calculatedItems.reduce((acc, item) => acc + item.totalBrl, 0);
  }, [calculatedItems]);

  const addItem = () => {
    setItems(prev => [
      ...prev,
      { id: Math.random().toString(36).substr(2, 9), produto: '', precoUsd: 0, prioridade: '' }
    ]);
  };

  const removeItem = (id: string) => {
    setItems(prev => prev.filter(item => item.id !== id));
  };

  const updateItem = (id: string, field: keyof CompraItem, value: any) => {
    setItems(prev => {
      return prev.map(item => 
        item.id === id ? { ...item, [field]: value } : item
      );
    });
  };

  return (
    <div className="space-y-6 font-sans text-white bg-[#000] p-4 md:p-6 border border-pm-metal shadow-2xl">
      <div className="flex flex-row items-center justify-between gap-4 mb-4 border-b border-[#333] pb-3">
        <h2 className="text-xl md:text-2xl font-bold text-[#ff4500] m-0">
          7. COMPRAS PESSOAIS
        </h2>
        <button 
          onClick={addItem}
          className="bg-[#ff4500] hover:bg-[#ff5a00] text-white px-4 py-2 text-[12px] font-bold rounded uppercase transition-colors shrink-0"
        >
          + Adicionar Produto
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-[14px] border-collapse min-w-[950px] bg-black">
          <thead>
            <tr className="bg-[#1a1a1a] text-[#ff4500] uppercase font-bold">
              <th className="p-3 border border-[#333]">ITEM</th>
              <th className="p-3 border border-[#333] w-32 text-center">VALOR (US$)</th>
              <th className="p-3 border border-[#333] w-32 text-center">COTA (US$)</th>
              <th className="p-3 border border-[#333] w-32 text-center">IMPOSTO (US$)</th>
              <th className="p-3 border border-[#333] w-32 text-center text-[#ff4500]">TOTAL (R$)</th>
              <th className="p-3 border border-[#333]">PRIORIDADE</th>
              <th className="p-3 border border-[#333] w-24 text-center">AÇÕES</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => {
              const calc = calculatedItems.find(c => c.id === item.id);
              const hasCota = (item.precoUsd || 0) > COTA;
              return (
                <tr key={item.id} className="hover:bg-pm-dark/30 transition-colors">
                  <td className="p-0 border border-[#333]">
                    <input 
                      type="text" 
                      value={item.produto}
                      onChange={(e) => updateItem(item.id, 'produto', e.target.value)}
                      placeholder="Novo Produto..."
                      className="w-full bg-transparent p-2 outline-none focus:bg-white/5 placeholder:text-white/10 italic"
                    />
                  </td>
                  <td className="p-0 border border-[#333]">
                    <input 
                      type="number" 
                      value={item.precoUsd || ''}
                      onChange={(e) => updateItem(item.id, 'precoUsd', parseFloat(e.target.value) || 0)}
                      className="w-full bg-transparent p-2 outline-none focus:bg-white/5 text-center"
                    />
                  </td>
                  <td className="p-2 border border-[#333] text-center text-white/60">
                    {hasCota ? `US$ ${COTA}` : '-'}
                  </td>
                  <td className="p-2 border border-[#333] text-center text-white/80">
                    {(calc?.impostoUsd || 0) > 0 ? `US$ ${calc?.impostoUsd.toFixed(2)}` : 'ISENTO'}
                  </td>
                  <td className="p-2 border border-[#333] font-black text-[#00ff00] text-center">
                    R$ {calc?.totalBrl.toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                  </td>
                  <td className="p-0 border border-[#333]">
                    <input 
                      type="text" 
                      value={item.prioridade}
                      onChange={(e) => updateItem(item.id, 'prioridade', e.target.value)}
                      placeholder="Prioridade"
                      className="w-full bg-transparent p-2 outline-none focus:bg-white/5 placeholder:text-white/10"
                    />
                  </td>
                  <td className="p-2 border border-[#333] text-center">
                    <button 
                      onClick={() => removeItem(item.id)}
                      className="bg-transparent hover:bg-[#ff0000]/10 border border-[#ff0000] text-[#ff0000] px-2 py-1 text-[11px] rounded transition-colors"
                    >
                      Deletar
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="mt-8 bg-pm-dark/40 border-l-4 border-pm-orange p-6 space-y-4 shadow-[0_0_30px_rgba(255,94,0,0.05)]">
        <div>
          <p className="text-[10px] font-black text-pm-orange uppercase tracking-[0.2em] mb-2 flex items-center gap-2">
            <Target size={12} /> ESTRATÉGIA DE AQUISIÇÃO
          </p>
          <textarea 
            value={estrategia}
            onChange={(e) => setEstrategia(e.target.value)}
            className="w-full bg-pm-black/60 border border-dashed border-pm-metal/50 p-4 text-xs italic text-white/50 focus:border-pm-orange focus:text-white outline-none resize-none min-h-[80px] font-mono leading-relaxed transition-all"
          />
        </div>
        
        <div className="flex flex-col items-end pt-4 border-t border-pm-metal/30">
          <span className="text-[10px] text-pm-orange font-bold uppercase tracking-widest opacity-70">TOTAL GERAL DA MISSÃO</span>
          <span className="text-4xl md:text-5xl font-black text-[#00ff00] italic tracking-tighter filter drop-shadow-[0_0_10px_rgba(0,255,0,0.4)]">
            R$ {totalGeral.toFixed(2)}
          </span>
        </div>
      </div>
    </div>
  );
}

