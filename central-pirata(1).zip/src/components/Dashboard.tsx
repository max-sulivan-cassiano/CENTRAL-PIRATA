import React from 'react';
import { motion } from 'motion/react';
import { 
  TrendingUp, 
  Package, 
  MapPin, 
  AlertTriangle,
  Zap,
  Globe,
  DollarSign
} from 'lucide-react';

export default function Dashboard() {
  const stats = [
    { label: 'LUCRO ESTIMADO (MAIO)', value: 'R$ 12.450', icon: TrendingUp, color: 'text-pm-orange' },
    { label: 'EQUIPAMENTOS EM TRÂNSITO', value: '14 UNID', icon: Package, color: 'text-pm-fire' },
    { label: 'LOCALIZAÇÃO ATUAL', value: 'FOZ DO IGUAÇU', icon: MapPin, color: 'text-pm-orange' },
    { label: 'RISCO LOGÍSTICO', value: 'MÉDIO', icon: AlertTriangle, color: 'text-red-600' },
  ];

  return (
    <div className="space-y-8">
      {/* Hero Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
            className="bg-pm-dark border-t-2 border-pm-orange p-6 relative overflow-hidden group hover:bg-pm-metal/10 transition-colors"
          >
            <p className="text-[9px] text-pm-orange opacity-50 uppercase font-bold tracking-widest">{stat.label}</p>
            <h3 className={`text-2xl font-black mt-2 tracking-tighter text-white uppercase italic`}>{stat.value}</h3>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Active Targets */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between mb-4 px-2">
            <h2 className="text-xs font-black uppercase tracking-widest text-pm-orange">Planilha V15 // Hardware Batch</h2>
            <span className="text-[10px] bg-pm-orange text-black px-2 font-bold uppercase">Cota: US$ 1000.00</span>
          </div>
          
          <div className="bg-pm-dark/20 border border-pm-orange/40 p-4">
            <table className="w-full text-left text-[11px] border-collapse">
              <thead>
                <tr className="uppercase font-normal text-white/50 border-b border-pm-orange/30">
                  <th className="py-2">ID UNIDADE</th>
                  <th className="py-2">ESTRATÉGIA</th>
                  <th className="py-2 text-pm-fire">LUCRO</th>
                  <th className="py-2 text-right">STATUS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-pm-metal">
                {[
                  { name: 'Poco X8 Pro Max (512GB)', strategy: '50% Fixo', roi: '+R$ 1.149,60', status: 'EM ESTOQUE' },
                  { name: 'MacBook Air M1 (Base)', strategy: 'Excedente Cota', roi: '+R$ 1.830,00', status: 'PRÉ-VENDA' },
                  { name: 'Capa Thule Gauntlet', strategy: 'Combo', roi: '+R$ 210,00', status: 'LISTA ESPERA' },
                ].map((item, i) => (
                  <tr key={i} className="hover:bg-pm-orange/5 transition-colors group">
                    <td className="py-3 font-bold text-white uppercase italic">{item.name}</td>
                    <td className="py-3 text-white/60">{item.strategy}</td>
                    <td className="py-3 font-bold text-pm-orange">{item.roi}</td>
                    <td className="py-3 text-right">
                      <span className="text-[9px] border border-pm-metal px-1 text-pm-orange/80 font-bold italic">
                        {item.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Global Markers */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <h2 className="text-xs font-bold uppercase tracking-widest">Inteligência de Mercado</h2>
          </div>
          
          <div className="bg-pm-dark border border-pm-metal p-6 space-y-6 shadow-[inset_0_0_20px_#000]">
            <div className="bg-pm-black border-t-2 border-pm-orange p-3">
              <span className="text-[9px] uppercase opacity-50">Spread Atual / USD-BRL</span>
              <div className="text-3xl font-black mt-1 tracking-tighter text-white">5.48<span className="text-sm text-pm-orange"> + 1.2%</span></div>
            </div>

            <div className="bg-pm-black border-t-2 border-orange-600 p-3">
              <span className="text-[9px] uppercase opacity-50">Imposto Estimado (50%)</span>
              <div className="text-3xl font-black mt-1 tracking-tighter text-orange-600">R$ 1.942,20</div>
            </div>

            <div className="pt-4 border-t border-pm-metal">
              <span className="text-[9px] uppercase font-bold text-white mb-2 underline block">Status do Firmware do Sistema</span>
              <div className="text-[10px] space-y-1">
                <p>&gt; KERNEL: V15_ESTÁVEL</p>
                <p>&gt; UPTIME: 428h 12m</p>
                <p className="text-pm-fire italic text-[9px] tracking-widest">&gt; TUNEL_CRIPTOGRAFADO: ATIVO</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
