import React, { useState } from 'react';
import { MapPin, Search, Plus, Save, X, ExternalLink } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

declare global {
  interface Window {
    google: any;
  }
}

interface LazerItem {
  id: string;
  nome: string;
  tipo?: string;
  cidade?: string;
  minhaNota: number;
  status: string;
  opiniao: string;
  googleData?: {
    endereco: string;
    nota: string;
    aberto: string;
    isOpen: boolean;
  };
}

export default function Lazer() {
  const [items, setItems] = useState<LazerItem[]>([
    {
      id: '1',
      nome: 'SHOPPING CHINA',
      tipo: 'COMPRAS',
      cidade: 'CDE',
      minhaNota: 5,
      status: 'ATIVO',
      opiniao: 'O santuário da tecnologia no Paraguai. Melhores preços e variedade absurda.',
      googleData: {
        endereco: 'Av. Luis Maria Argaña, Cd. del Este',
        nota: '4.8 ⭐',
        aberto: 'ABERTO AGORA',
        isOpen: true
      }
    }
  ]);

  const [selectedId, setSelectedId] = useState<string | null>('1');
  const [isScanning, setIsScanning] = useState(false);

  const selectedItem = items.find(item => item.id === selectedId) || null;

  const updateItem = (id: string, field: keyof LazerItem, value: any) => {
    setItems(prev => prev.map(item => item.id === id ? { ...item, [field]: value } : item));
  };

  const executarVarredura = (id: string, nome: string) => {
    if (!nome) return;
    setIsScanning(true);
    
    // Check if Google Maps is available
    if (window.google && window.google.maps && window.google.maps.places) {
      const service = new window.google.maps.places.PlacesService(document.createElement('div'));
      const request = {
        query: nome,
        fields: ['name', 'formatted_address', 'rating', 'opening_hours']
      };

      service.findPlaceFromQuery(request, (results: any, status: any) => {
        if (status === window.google.maps.places.PlacesServiceStatus.OK && results[0]) {
          const place = results[0];
          setItems(prev => prev.map(item => {
            if (item.id === id) {
              return {
                ...item,
                status: 'CONCLUÍDO',
                googleData: {
                  endereco: place.formatted_address || 'Endereço não encontrado',
                  nota: `${place.rating || 'N/A'} ⭐`,
                  aberto: place.opening_hours?.isOpen() ? 'ABERTO AGORA' : (place.opening_hours ? 'FECHADO NO MOMENTO' : '---'),
                  isOpen: place.opening_hours?.isOpen() || false
                }
              };
            }
            return item;
          }));
        } else {
          // Fallback if not found on Google
          setItems(prev => prev.map(item => item.id === id ? { ...item, status: 'NÃO ENCONTRADO' } : item));
        }
        setIsScanning(false);
      });
    } else {
      // Fallback Simulation if API is not loaded or Key is invalid
      setTimeout(() => {
        setItems(prev => prev.map(item => {
          if (item.id === id) {
            const isChina = nome.toUpperCase().includes('CHINA');
            return {
              ...item,
              status: 'CONCLUÍDO (SIM)',
              googleData: isChina ? {
                endereco: 'Av. Luis Maria Argaña, Cd. del Este',
                nota: '4.8 ⭐',
                aberto: 'ABERTO AGORA',
                isOpen: true
              } : {
                endereco: 'Emulado: Av. das Cataratas, 123',
                nota: '4.1 ⭐',
                aberto: 'STATUS EMULADO',
                isOpen: true
              }
            };
          }
          return item;
        }));
        setIsScanning(false);
      }, 1200);
    }
  };

  const addAsset = () => {
    const newItem: LazerItem = {
      id: Math.random().toString(36).substr(2, 9),
      nome: '',
      tipo: '',
      cidade: '',
      minhaNota: 0,
      status: 'AGUARDANDO',
      opiniao: ''
    };
    setItems(prev => [...prev, newItem]);
    setSelectedId(newItem.id);
  };

  return (
    <div className="space-y-6 font-mono text-white">
      <div className="flex items-center justify-between mb-8 pb-4 border-b-2 border-pm-orange">
        <h2 className="text-2xl font-black uppercase tracking-[0.2em] text-pm-orange flex items-center gap-3">
          6. LAZER
        </h2>
        <button 
          onClick={addAsset}
          className="bg-pm-orange hover:bg-pm-fire text-black px-6 py-2 font-black uppercase tracking-widest transition-all shadow-[2px_2px_0px_#882200] transform active:scale-95 flex items-center gap-2"
        >
          <Plus size={18} /> + NOVO LUGAR
        </button>
      </div>

      <div className="overflow-x-auto bg-pm-black border border-pm-metal mb-8 shadow-2xl">
        <table className="w-full text-left text-[11px] border-collapse min-w-[800px]">
          <thead>
            <tr className="bg-pm-dark uppercase font-black text-pm-orange border-b border-pm-metal">
              <th className="p-3 border-r border-pm-metal">LUGAR</th>
              <th className="p-3 border-r border-pm-metal">TIPO</th>
              <th className="p-3 border-r border-pm-metal">CIDADE</th>
              <th className="p-3 border-r border-pm-metal w-[140px]">MINHA NOTA</th>
              <th className="p-3">STATUS</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-pm-metal">
            {items.map((item) => (
              <tr 
                key={item.id} 
                className={`transition-colors group hover:bg-pm-dark/20 ${selectedId === item.id ? 'bg-pm-orange/5' : ''}`}
                onClick={() => setSelectedId(item.id)}
              >
                <td className="p-1 border-r border-pm-metal">
                  <input 
                    type="text" 
                    value={item.nome}
                    onChange={(e) => updateItem(item.id, 'nome', e.target.value)}
                    onBlur={(e) => executarVarredura(item.id, e.target.value)}
                    onFocus={() => setSelectedId(item.id)}
                    placeholder="Ex: Shopping China..."
                    className="w-full bg-transparent p-2 outline-none focus:bg-pm-dark/50 font-black text-white uppercase placeholder:text-white/10"
                  />
                </td>
                <td className="p-1 border-r border-pm-metal">
                  <input 
                    type="text" 
                    value={item.tipo || ''}
                    onChange={(e) => updateItem(item.id, 'tipo', e.target.value)}
                    onFocus={() => setSelectedId(item.id)}
                    placeholder="Tipo"
                    className="w-full bg-transparent p-2 outline-none focus:bg-pm-dark/50 font-bold text-pm-orange uppercase placeholder:text-white/10"
                  />
                </td>
                <td className="p-1 border-r border-pm-metal">
                  <input 
                    type="text" 
                    value={item.cidade || ''}
                    onChange={(e) => updateItem(item.id, 'cidade', e.target.value)}
                    onFocus={() => setSelectedId(item.id)}
                    placeholder="Cidade"
                    className="w-full bg-transparent p-2 outline-none focus:bg-pm-dark/50 text-white uppercase placeholder:text-white/10"
                  />
                </td>
                <td className="p-1 border-r border-pm-metal">
                  <div className="flex px-2 gap-1 h-full items-center">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button 
                        key={star}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          updateItem(item.id, 'minhaNota', star);
                          setSelectedId(item.id);
                        }}
                        className={`text-xl transition-all ${item.minhaNota >= star ? 'text-pm-orange drop-shadow-[0_0_8px_#ff4500]' : 'text-pm-dark hover:text-white/20'}`}
                      >
                        ★
                      </button>
                    ))}
                  </div>
                </td>
                <td className="p-1">
                  <input 
                    type="text" 
                    value={item.status || ''}
                    readOnly
                    className={`w-full bg-transparent p-2 outline-none font-black ${item.status === 'CONCLUÍDO' ? 'text-[#00ff00]' : 'text-pm-metal'} uppercase`}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="bg-[#050505] border border-pm-metal p-8 relative flex flex-col md:flex-row gap-8">
        <div className="flex-1 space-y-4">
          <h3 className="text-xl font-black text-white uppercase tracking-tighter flex items-center gap-2">
            {isScanning ? (
              <>
                <Search className="animate-pulse text-pm-orange" size={20} />
                VARRENDO INTERNET: {selectedItem?.nome.toUpperCase() || "..."}
              </>
            ) : (
              selectedItem?.nome.toUpperCase() || "AGUARDANDO VARREDURA..."
            )}
          </h3>
          <div className="text-[13px] text-pm-metal space-y-2 font-mono">
            <p className="flex items-center gap-2">
              <span className="opacity-50">Endereço:</span> 
              <span className="text-white/80">{selectedItem?.googleData?.endereco || "---"}</span>
            </p>
            <p className="flex items-center gap-2">
              <span className="opacity-50">Nota Google:</span> 
              <span className="text-white/80">{selectedItem?.googleData?.nota || "---"}</span>
            </p>
            <p className="flex items-center gap-2">
              <span className="opacity-50">Funcionamento:</span> 
              <span className={selectedItem?.googleData?.isOpen ? "text-[#00ff00]" : "text-pm-fire"}>
                {selectedItem?.googleData?.aberto || "---"}
              </span>
            </p>
          </div>
        </div>

        <div className="flex-1 space-y-3 md:border-l border-pm-metal md:pl-8">
          <label className="text-[10px] text-pm-metal font-black uppercase tracking-widest block opacity-70">
            MINHA OPINIÃO PESSOAL:
          </label>
          <textarea 
            value={selectedItem?.opiniao || ''}
            onChange={(e) => updateItem(selectedId!, 'opiniao', e.target.value)}
            placeholder="Digite aqui suas impressões sobre este local..."
            className="w-full h-24 bg-pm-black border border-dashed border-pm-metal p-4 text-[#00ff00] text-sm italic font-mono outline-none focus:border-pm-orange transition-all resize-none shadow-[inset_0_0_10px_rgba(0,0,0,0.5)]"
          />
        </div>
      </div>
    </div>
  );
}

