import React, { useState } from 'react';
import { Hotel, Phone, MapPin, Clock, Plus } from 'lucide-react';

interface HotelItem {
  id: string;
  hotel: string;
  checkIn: string;
  checkOut: string;
  valorDiaria: string;
}

const DB_HOTEIS: Record<string, { nome: string, end: string, link: string }> = {
  "vivaldi": { nome: "Rede Andrade Vivaldi Hotel", end: "R. Sérgio Gaspareto, 934 - Portal da Foz", link: "https://www.google.com/maps/search/?api=1&query=Rede+Andrade+Vivaldi+Hotel+Foz+do+Iguaçu" },
  "fronteira": { nome: "Foz Fronteira Hotel", end: "R. Antônio Salazar, 31 - Lancaster", link: "https://www.google.com/maps/search/?api=1&query=Foz+Fronteira+Hotel+Foz+do+Iguaçu" },
  "nações": { nome: "Hotel Dan Inn Express (Nações)", end: "Av. Juscelino Kubitscheck, 3485 - Jd. Nações", link: "https://www.google.com/maps/search/?api=1&query=Hotel+Dan+Inn+Express+Foz+do+Iguaçu" },
  "trevisan": { nome: "Hotel Trevita em Foz", end: "Av. Costa e Silva, 887 - Jd. Manaus", link: "https://www.google.com/maps/search/?api=1&query=Hotel+Trevita+Foz+do+Iguaçu" },
  "3 fronteiras": { nome: "Hotel Três Fronteiras", end: "Av. Jorge Schimmelpfeng, 605 - Centro", link: "https://www.google.com/maps/search/?api=1&query=Hotel+Três+Fronteiras+Foz+do+Iguaçu" },
  "center": { nome: "Hotel Iguaçu Centro", end: "Av. Brasil, 1140 - Centro", link: "https://www.google.com/maps/search/?api=1&query=Hotel+Iguaçu+Centro+Foz+do+Iguaçu" },
  "shaddai": { nome: "Pousada El Shaddai", end: "R. Eng. Rebouças, 306 - Centro", link: "https://www.google.com/maps/search/?api=1&query=Pousada+El+Shaddai+Foz+do+Iguaçu" },
  "carol": { nome: "Carol Palace Hotel", end: "R. Padre Manoel de Nóbrega, 204 - Vila Brasilia", link: "https://www.google.com/maps/search/?api=1&query=Carol+Palace+Hotel+Foz+do+Iguaçu" }
};

export default function Hospedagem() {
  const [hoteis, setHoteis] = useState<HotelItem[]>([
    { 
      id: '1', 
      hotel: '', 
      checkIn: '--/--/--', 
      checkOut: '--/--/--', 
      valorDiaria: 'R$ 0,00'
    }
  ]);

  const [activeMapsInfo, setActiveMapsInfo] = useState<{ nome: string, end: string, link: string } | null>(null);

  const addHotel = () => {
    setHoteis(prev => [
      ...prev,
      { 
        id: Math.random().toString(36).substr(2, 9), 
        hotel: '', 
        checkIn: '--/--/--', 
        checkOut: '--/--/--', 
        valorDiaria: 'R$ 0,00'
      }
    ]);
  };

  const removeHotel = (id: string) => {
    setHoteis(prev => prev.filter(h => h.id !== id));
    setActiveMapsInfo(null);
  };

  const buscarMapsFoz = (val: string) => {
    const term = val.toLowerCase();
    let found = null;

    for (const key in DB_HOTEIS) {
      if (term.includes(key)) {
        found = DB_HOTEIS[key];
        break;
      }
    }
    setActiveMapsInfo(found);
  };

  const updateHotel = (id: string, field: keyof HotelItem, value: string) => {
    if (field === 'hotel') buscarMapsFoz(value);
    setHoteis(prev => prev.map(h => h.id === id ? { ...h, [field]: value } : h));
  };

  return (
    <div id="aba-8-hospedagem" className="p-4 bg-black font-sans text-white border border-[#333] shadow-2xl space-y-6">
      
      <div className="flex justify-between items-center border-b-2 border-[#ff4500] pb-[10px] mb-[15px]">
        <h2 className="text-[#ff4500] text-xl md:text-2xl font-bold m-0 uppercase tracking-tight">
          8. DETALHES DA HOSPEDAGEM
        </h2>
        
        <button 
          onClick={addHotel}
          className="bg-[#ff4500] hover:bg-[#ff5a00] text-white px-4 py-2 text-[11px] font-bold rounded uppercase transition-colors shrink-0"
        >
          + ADICIONAR
        </button>
      </div>

      <div className="overflow-x-auto">
        <table id="table-hospedagem" className="w-full text-left text-[14px] border-collapse mb-[20px]">
          <thead>
            <tr className="bg-[#1a1a1a] text-[#ff4500] uppercase font-bold text-[12px]">
              <th className="p-3 border border-[#333]">Hotel / Local</th>
              <th className="p-3 border border-[#333] w-32">Check-in</th>
              <th className="p-3 border border-[#333] w-32">Check-out</th>
              <th className="p-3 border border-[#333] w-32">Diária (R$)</th>
              <th className="p-3 border border-[#333] w-24 text-center">Ações</th>
            </tr>
          </thead>
          <tbody>
            {hoteis.map((h) => (
              <tr key={h.id} className="hover:bg-white/5 transition-colors">
                <td className="p-0 border border-[#333]">
                  <input 
                    type="text"
                    value={h.hotel}
                    onChange={(e) => updateHotel(h.id, 'hotel', e.target.value)}
                    placeholder="Digite o nome do hotel..."
                    className="w-full bg-transparent p-2 outline-none focus:bg-white/5 font-bold text-[#0f0] placeholder:text-white/20"
                  />
                </td>
                <td className="p-0 border border-[#333]">
                  <input 
                    type="text"
                    value={h.checkIn}
                    onChange={(e) => updateHotel(h.id, 'checkIn', e.target.value)}
                    placeholder="--/--/--"
                    className="w-full bg-transparent p-2 outline-none focus:bg-white/5 text-center"
                  />
                </td>
                <td className="p-0 border border-[#333]">
                  <input 
                    type="text"
                    value={h.checkOut}
                    onChange={(e) => updateHotel(h.id, 'checkOut', e.target.value)}
                    placeholder="--/--/--"
                    className="w-full bg-transparent p-2 outline-none focus:bg-white/5 text-center"
                  />
                </td>
                <td className="p-0 border border-[#333]">
                  <input 
                    type="text"
                    value={h.valorDiaria}
                    onChange={(e) => updateHotel(h.id, 'valorDiaria', e.target.value)}
                    placeholder="R$ 0,00"
                    className="w-full bg-transparent p-2 outline-none focus:bg-white/5 text-center"
                  />
                </td>
                <td className="p-2 border border-[#333] text-center">
                  <button 
                    onClick={() => removeHotel(h.id)}
                    className="bg-transparent hover:bg-[#ff0000]/10 border border-[#ff0000] text-[#ff0000] px-2 py-1 text-[11px] rounded transition-colors"
                  >
                    Deletar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {activeMapsInfo && (
        <div id="info-maps-display" className="bg-[#111] border border-[#444] p-4 rounded animate-in fade-in slide-in-from-bottom-2">
          <div className="flex items-start gap-4">
            <a 
              href={activeMapsInfo.link} 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-[#4285F4] hover:bg-[#357ae8] text-white px-3 py-2 rounded font-bold text-sm shrink-0 transition-colors no-underline"
            >
              MAPS
            </a>
            <div>
              <h3 className="m-0 text-white font-bold text-lg">{activeMapsInfo.nome}</h3>
              <p className="my-1 text-[#aaa] text-[13px]">{activeMapsInfo.end}</p>
              <span className="text-[#0f0] text-[11px] border border-[#0f0] px-1.5 py-0.5 rounded">
                Clique no ícone MAPS para abrir
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
