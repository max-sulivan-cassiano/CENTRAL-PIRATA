import React, { useState } from 'react';

interface Viagem {
  id: string;
  destino: string;
  data: string;
  custoEstrada: number;
  custoAlimentacao: number;
  custoLazer: number;
}

export default function Logistics() {
  const [viagens, setViagens] = useState<Viagem[]>([
    { 
      id: '1', 
      destino: 'Paraguai (CDE)', 
      data: 'Maio/2026',
      custoEstrada: 0,
      custoAlimentacao: 0,
      custoLazer: 0
    }
  ]);

  const addViagem = () => {
    setViagens(prev => [
      ...prev,
      { 
        id: Math.random().toString(36).substr(2, 9), 
        destino: '', 
        data: '', 
        custoEstrada: 0,
        custoAlimentacao: 0,
        custoLazer: 0
      }
    ]);
  };

  const removeViagem = (id: string) => {
    setViagens(prev => prev.filter(v => v.id !== id));
  };

  const updateViagem = (id: string, field: keyof Viagem, value: string | number) => {
    setViagens(prev => prev.map(v => v.id === id ? { ...v, [field]: value } : v));
  };

  return (
    <div id="logistica-viagens" className="p-4 bg-black font-sans text-white border border-[#333] shadow-2xl space-y-6">
      
      <div className="flex justify-between items-center border-b-2 border-[#ff4500] pb-[10px] mb-[20px]">
        <h2 className="text-[#ff4500] text-xl md:text-2xl font-bold m-0 uppercase tracking-tight">
          3. VIAGENS
        </h2>
        
        <button 
          onClick={addViagem}
          className="bg-[#ff4500] hover:bg-[#ff5a00] text-white px-4 py-2 text-[11px] font-bold rounded uppercase transition-colors shrink-0"
        >
          + Adicionar Viagem
        </button>
      </div>

      <div className="overflow-x-auto">
        <table id="table-viagens" className="w-full text-left text-[14px] border-collapse min-w-[850px]">
          <thead>
            <tr className="bg-[#1a1a1a] text-[#ff4500] uppercase font-bold text-[12px]">
              <th className="p-3 border border-[#333]">Destino</th>
              <th className="p-3 border border-[#333] w-40">Data Prevista</th>
              <th className="p-3 border border-[#333] w-32">Estrada (R$)</th>
              <th className="p-3 border border-[#333] w-32">Alimentação (R$)</th>
              <th className="p-3 border border-[#333] w-32">Lazer/Conv. (R$)</th>
              <th className="p-3 border border-[#333] w-32 text-white">Custo Total</th>
              <th className="p-3 border border-[#333] w-24 text-center">Ações</th>
            </tr>
          </thead>
          <tbody>
            {viagens.map((v) => {
              const total = (v.custoEstrada || 0) + (v.custoAlimentacao || 0) + (v.custoLazer || 0);
              return (
                <tr key={v.id} className="hover:bg-white/5 transition-colors">
                  <td className="p-0 border border-[#333]">
                    <input 
                      type="text"
                      value={v.destino}
                      onChange={(e) => updateViagem(v.id, 'destino', e.target.value)}
                      placeholder="Destino..."
                      className="w-full bg-transparent p-2 outline-none focus:bg-white/5"
                    />
                  </td>
                  <td className="p-0 border border-[#333]">
                    <input 
                      type="text"
                      value={v.data}
                      onChange={(e) => updateViagem(v.id, 'data', e.target.value)}
                      placeholder="Maio/2026"
                      className="w-full bg-transparent p-2 outline-none focus:bg-white/5"
                    />
                  </td>
                  <td className="p-0 border border-[#333]">
                    <input 
                      type="number"
                      step="0.01"
                      value={v.custoEstrada || ''}
                      onChange={(e) => updateViagem(v.id, 'custoEstrada', parseFloat(e.target.value) || 0)}
                      className="w-full bg-transparent p-2 outline-none focus:bg-white/5 text-white"
                      placeholder="0.00"
                    />
                  </td>
                  <td className="p-0 border border-[#333]">
                    <input 
                      type="number"
                      step="0.01"
                      value={v.custoAlimentacao || ''}
                      onChange={(e) => updateViagem(v.id, 'custoAlimentacao', parseFloat(e.target.value) || 0)}
                      className="w-full bg-transparent p-2 outline-none focus:bg-white/5 text-white"
                      placeholder="0.00"
                    />
                  </td>
                  <td className="p-0 border border-[#333]">
                    <input 
                      type="number"
                      step="0.01"
                      value={v.custoLazer || ''}
                      onChange={(e) => updateViagem(v.id, 'custoLazer', parseFloat(e.target.value) || 0)}
                      className="w-full bg-transparent p-2 outline-none focus:bg-white/5 text-white"
                      placeholder="0.00"
                    />
                  </td>
                  <td className="p-2 border border-[#333] font-bold text-[#0f0]">
                    R$ {total.toFixed(2)}
                  </td>
                  <td className="p-2 border border-[#333] text-center">
                    <button 
                      onClick={() => removeViagem(v.id)}
                      className="bg-transparent hover:bg-[#ff0000]/10 border border-[#ff0000] text-[#ff0000] px-2 py-1 text-[11px] rounded transition-colors"
                    >
                      Deletar
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
