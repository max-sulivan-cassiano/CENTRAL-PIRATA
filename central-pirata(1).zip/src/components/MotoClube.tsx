import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Shield, MapPin } from 'lucide-react';

export default function MotoClube() {
  const [data, setData] = useState({
    regional: '',
    cidade: '',
    contato: '',
    evento: '',
    obs: ''
  });

  const mapsLink = data.regional.length > 3
    ? `https://www.google.com/maps/search/${encodeURIComponent(data.regional + " Insanos Moto Clube")}`
    : null;

  return (
    <div className="space-y-6 font-mono">
      <div className="flex items-center justify-between mb-4 px-2 border-b-2 border-pm-orange pb-2">
        <h2 className="text-xl font-black uppercase tracking-widest text-pm-orange flex items-center gap-2">
          📍 Logística Moto Clube
        </h2>
        <img src="/asset_2.png" alt="Divisão MC" className="w-12 h-12 drop-shadow-[0_0_8px_#FF5E0044]" />
      </div>
      
      <div className="bg-pm-black border border-pm-metal p-1 overflow-x-auto">
        <table className="w-full text-left text-[11px] border-collapse min-w-[900px]">
          <thead>
            <tr className="bg-pm-dark/40 uppercase font-bold text-pm-orange border-b border-pm-metal">
              <th className="p-3 border border-pm-metal/30">Regional / Divisão</th>
              <th className="p-3 border border-pm-metal/30">Cidade</th>
              <th className="p-3 border border-pm-metal/30 text-center">Endereço / Sede (Link)</th>
              <th className="p-3 border border-pm-metal/30">Contato Suporte</th>
              <th className="p-3 border border-pm-metal/30">Próximo Evento</th>
              <th className="p-3 border border-pm-metal/30">Observações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-pm-metal">
            <tr className="bg-pm-black">
              {/* Regional */}
              <td className="p-2 border border-pm-metal/30">
                <input 
                  type="text" 
                  value={data.regional}
                  onChange={(e) => setData({...data, regional: e.target.value})}
                  placeholder="Digite a Regional..."
                  className="bg-pm-dark/50 border border-pm-metal/50 text-white p-2 text-[11px] w-full focus:border-pm-orange outline-none uppercase italic placeholder:text-white/20"
                />
              </td>

              {/* Cidade */}
              <td className="p-2 border border-pm-metal/30">
                <input 
                  type="text" 
                  value={data.cidade}
                  onChange={(e) => setData({...data, cidade: e.target.value})}
                  placeholder="Cidade"
                  className="bg-pm-dark/50 border border-pm-metal/50 text-white p-2 text-[11px] w-full focus:border-pm-orange outline-none uppercase italic placeholder:text-white/20"
                />
              </td>

              {/* Endereço / Sede (Link) */}
              <td className="p-2 border border-pm-metal/30 text-center align-middle">
                {mapsLink ? (
                  <a 
                    href={mapsLink} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[#00ff00] hover:underline uppercase font-bold tracking-tighter glow-green text-[10px]"
                  >
                    📍 ABRIR MAPA
                  </a>
                ) : (
                  <span className="text-white/20 font-bold tracking-tighter">---</span>
                )}
              </td>

              {/* Contato Suporte */}
              <td className="p-2 border border-pm-metal/30">
                <input 
                  type="text" 
                  value={data.contato}
                  onChange={(e) => setData({...data, contato: e.target.value})}
                  placeholder="(00) 00000-0000"
                  className="bg-pm-dark/50 border border-pm-metal/50 text-white p-2 text-[11px] w-full focus:border-pm-orange outline-none uppercase italic placeholder:text-white/20"
                />
              </td>

              {/* Próximo Evento */}
              <td className="p-2 border border-pm-metal/30">
                <input 
                  type="date" 
                  value={data.evento}
                  onChange={(e) => setData({...data, evento: e.target.value})}
                  className="bg-pm-dark/50 border border-pm-metal/50 text-white p-2 text-[11px] w-full focus:border-pm-orange outline-none uppercase italic"
                />
              </td>

              {/* Observações */}
              <td className="p-2 border border-pm-metal/30">
                <textarea 
                  value={data.obs}
                  onChange={(e) => setData({...data, obs: e.target.value})}
                  rows={1}
                  placeholder="Notas da missão..."
                  className="bg-pm-dark/50 border border-pm-metal/50 text-white p-2 text-[11px] w-full focus:border-pm-orange outline-none uppercase italic placeholder:text-white/20 resize-none min-h-[36px]"
                />
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="bg-pm-dark border border-pm-metal p-6 flex items-center gap-6">
        <div className="w-12 h-12 bg-pm-orange/10 border border-pm-orange flex items-center justify-center shrink-0 shadow-[0_0_15px_#FF5E0044]">
          <Shield className="text-pm-orange" size={24} />
        </div>
        <div>
          <p className="text-[10px] text-pm-fire font-bold uppercase tracking-widest underline">Protocolo MC_V15</p>
          <p className="text-xs text-white opacity-70 leading-relaxed italic">
            "Mantenha sempre o contato suporte atualizado. Em caso de parada em zona de risco, acione o sinalizador de posição via Terminal Central."
          </p>
        </div>
      </div>
    </div>
  );
}
