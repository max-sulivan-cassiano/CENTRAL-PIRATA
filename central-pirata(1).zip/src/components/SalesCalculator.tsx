import React, { useState, useMemo } from 'react';
import { RefreshCw, Plus, Target, DollarSign, TrendingUp } from 'lucide-react';
import { motion } from 'motion/react';

interface Venda {
  id: string;
  cliente: string;
  produto: string;
  precoPy: number;
  cambio: number;
}

export default function SalesCalculator() {
  const [calcPrecoPy, setCalcPrecoPy] = useState<number>(0);
  const [calcCambio, setCalcCambio] = useState<number>(5.42);
  const [calcMargem, setCalcMargem] = useState<number>(20);
  const [isCalculating, setIsCalculating] = useState(false);

  const [vendas, setVendas] = useState<Venda[]>([
    { id: '1', cliente: '', produto: '', precoPy: 0, cambio: 5.42 }
  ]);

  const results = useMemo(() => {
    const preco = calcPrecoPy || 0;
    const cambio = calcCambio || 0;
    const margemPct = calcMargem || 0;

    // 1. Cálculo do PREÇO R$ (Dólar x Câmbio)
    const custoConvertido = preco * cambio;

    // 2. Cálculo do Imposto (50% sobre excedente de US$ 500)
    const excedente = preco > 500 ? (preco - 500) : 0;
    const impostoBRL = (excedente * 0.50) * cambio;

    // 3. Custo Final e Margem
    const custoFinal = custoConvertido + impostoBRL;
    const valorLucro = custoFinal * (margemPct / 100);
    const sugestaoVenda = custoFinal + valorLucro;

    return {
      custoConvertido,
      impostoBRL,
      custoFinal,
      valorLucro,
      sugestaoVenda
    };
  }, [calcPrecoPy, calcCambio, calcMargem]);

  const handleCalculate = () => {
    setIsCalculating(true);
    setTimeout(() => {
      setIsCalculating(false);
    }, 800);
  };

  const adicionarVenda = () => {
    setVendas([...vendas, { 
      id: Math.random().toString(36).substr(2, 9), 
      cliente: '', 
      produto: '', 
      precoPy: 0, 
      cambio: calcCambio 
    }]);
  };

  const updateVenda = (id: string, field: keyof Venda, value: any) => {
    setVendas(prev => prev.map(v => v.id === id ? { ...v, [field]: value } : v));
  };

  return (
    <div className="space-y-8 font-mono text-white">
      {/* 1. REGISTRO DE VENDAS CALCULATOR */}
      <div className="bg-pm-black p-6 md:p-8 border-2 border-pm-metal shadow-2xl relative">
        <div className="absolute -top-4 left-6 bg-pm-black px-4 border border-pm-metal">
          <h2 className="text-xl md:text-2xl font-black uppercase tracking-widest text-pm-orange flex items-center gap-3">
            <Target size={24} className="text-pm-orange" />
            1. REGISTRO DE VENDAS
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 mt-6 mb-8 bg-pm-dark/30 p-4 border border-pm-metal/50">
          <div className="space-y-2">
            <label className="text-[9px] text-pm-metal font-black uppercase tracking-widest block opacity-70">PREÇO PY (US$)</label>
            <input 
              type="number" 
              value={calcPrecoPy || ''} 
              onChange={(e) => setCalcPrecoPy(Number(e.target.value))}
              placeholder="0.00"
              className="w-full bg-pm-black border-b border-pm-metal p-3 text-xl font-black text-white outline-none focus:border-pm-orange transition-all placeholder:text-white/10"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[9px] text-pm-metal font-black uppercase tracking-widest block opacity-70">CÂMBIO (R$)</label>
            <input 
              type="number" 
              value={calcCambio || ''} 
              onChange={(e) => setCalcCambio(Number(e.target.value))}
              step="0.01"
              className="w-full bg-pm-black border-b border-pm-metal p-3 text-xl font-black text-white outline-none focus:border-pm-orange transition-all"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[9px] text-pm-metal font-black uppercase tracking-widest block opacity-70">PREÇO R$ (AUTO)</label>
            <input 
              type="text" 
              value={results.custoConvertido.toLocaleString('pt-BR', {minimumFractionDigits: 2})} 
              readOnly
              className="w-full bg-pm-black/50 border-b border-pm-metal p-3 text-xl font-black text-white/40 outline-none"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[9px] text-pm-fire font-black uppercase tracking-widest block opacity-90 font-bold">IMPOSTO (R$)</label>
            <input 
              type="text" 
              value={results.impostoBRL.toLocaleString('pt-BR', {minimumFractionDigits: 2})} 
              readOnly
              className="w-full bg-pm-black/50 border-b border-pm-fire/30 p-3 text-xl font-black text-pm-fire outline-none"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[9px] text-[#00ff00] font-black uppercase tracking-widest block opacity-90">MARGEM (%)</label>
            <input 
              type="number" 
              value={calcMargem || ''} 
              onChange={(e) => setCalcMargem(Number(e.target.value))}
              className="w-full bg-pm-black border-b border-[#00ff00]/30 p-3 text-xl font-black text-[#00ff00] outline-none focus:glow-green transition-all"
            />
          </div>
        </div>

        <button 
          onClick={handleCalculate}
          className="w-full bg-pm-orange p-4 text-black font-black uppercase tracking-[0.3em] hover:bg-white transition-all shadow-[0_0_20px_rgba(255,94,0,0.3)] mb-8 active:scale-[0.99]"
        >
          {isCalculating ? "PROCESSANDO_DADOS..." : "CALCULAR MISSÃO"}
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 border-t border-pm-metal/30 pb-4">
          <div className="bg-pm-dark/40 p-4 border border-pm-metal/30 flex justify-between items-center">
            <div>
              <p className="text-[10px] text-white/40 font-black uppercase mb-1">CUSTO FINAL ACUMULADO:</p>
              <p className="text-xl font-bold text-white italic">R$ {results.custoFinal.toLocaleString('pt-BR', {minimumFractionDigits: 2})}</p>
            </div>
          </div>
          <div className="bg-pm-dark/40 p-4 border border-pm-metal/30 text-right">
            <p className="text-[10px] text-white/40 font-black uppercase mb-1">LUCRO ESTIMADO:</p>
            <p className="text-xl font-bold text-[#00ff00] italic">R$ {results.valorLucro.toLocaleString('pt-BR', {minimumFractionDigits: 2})}</p>
          </div>
        </div>

        <div className="mt-4 bg-pm-dark p-8 border-2 border-pm-orange shadow-[inset_0_0_10px_#ff450033] text-center relative overflow-hidden group">
          <p className="text-xs text-white/50 font-black uppercase tracking-[0.4em] mb-2">SUGESTÃO DE VENDA (MARGEM SEGURA):</p>
          <motion.h2 
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            className="text-5xl md:text-6xl font-black text-[#00ff00] glow-green italic tracking-tighter relative z-10"
          >
            R$ {results.sugestaoVenda.toLocaleString('pt-BR', {minimumFractionDigits: 2})}
          </motion.h2>
          <div className="absolute inset-0 bg-pm-orange/5 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />
        </div>
      </div>

      {/* 2. SALES TABLE */}
      <div className="bg-pm-black p-6 border border-pm-metal">
        <div className="flex items-center justify-between mb-6 border-b border-pm-metal/30 pb-3">
          <h3 className="text-sm font-black uppercase tracking-widest text-pm-orange flex items-center gap-2">
            <TrendingUp size={16} /> REGISTRO OPERACIONAL
          </h3>
          <button 
            onClick={adicionarVenda}
            className="bg-pm-metal/50 text-white px-3 py-1 font-bold text-[10px] flex items-center gap-2 hover:bg-pm-orange hover:text-black transition-all"
          >
            <Plus size={12} /> ADICIONAR LINHA
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-[11px] border-collapse min-w-[700px]">
            <thead>
              <tr className="bg-pm-dark/40 uppercase font-black text-pm-orange border-b border-pm-metal">
                <th className="p-4 border-r border-pm-metal">CLIENTE</th>
                <th className="p-4 border-r border-pm-metal">PRODUTO</th>
                <th className="p-4 text-right">VALOR FINAL</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-pm-metal">
              {vendas.map((v) => (
                <tr key={v.id} className="hover:bg-pm-dark/20 transition-colors">
                  <td className="p-1 border-r border-pm-metal">
                    <input 
                      type="text" 
                      value={v.cliente}
                      onChange={(e) => updateVenda(v.id, 'cliente', e.target.value)}
                      placeholder="Nome do Cliente..."
                      className="w-full bg-transparent p-3 outline-none focus:bg-pm-black/80 placeholder:text-white/5 uppercase italic"
                    />
                  </td>
                  <td className="p-1 border-r border-pm-metal">
                    <input 
                      type="text" 
                      value={v.produto}
                      onChange={(e) => updateVenda(v.id, 'produto', e.target.value)}
                      placeholder="Item da Missão..."
                      className="w-full bg-transparent p-3 outline-none focus:bg-pm-black/80 placeholder:text-white/5 uppercase italic"
                    />
                  </td>
                  <td className="p-4 font-black text-[#00ff00] italic text-right bg-pm-dark/20 text-lg glow-green">
                    {calcPrecoPy > 0 
                      ? `R$ ${results.sugestaoVenda.toLocaleString('pt-BR', {minimumFractionDigits: 2})}` 
                      : 'R$ 0,00'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-pm-dark/40 p-4 border-l-4 border-pm-fire flex items-center justify-between text-[10px] opacity-60">
        <span className="flex items-center gap-2 italic uppercase">
          <RefreshCw size={12} className="animate-spin-slow" /> CALCULADORA V15 EXECUTANDO_PROTOCOLO_MARGEM_SEGURA
        </span>
        <span className="font-mono">BUILD_V15.42_STABLE</span>
      </div>
    </div>
  );
}
