import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export default function LoadingScreen({ onComplete }: { onComplete: () => void }) {
  const [logs, setLogs] = useState<number[]>([]);
  const [progress, setProgress] = useState(0);

  const logTexts = [
    '> INICIALIZANDO NÚCLEO PIRATA ...',
    '> CARREGANDO MOTORES DE CÁLCULO V15',
    '> SINCRONIZANDO COM FOZ_BASE_DB',
    '> STATUS: CONEXÃO SEGURA ESTABELECIDA'
  ];

  useEffect(() => {
    const intervals = logTexts.map((_, index) => {
      return setTimeout(() => {
        setLogs(prev => [...prev, index]);
        setProgress((index + 1) * 25);
        if (index === logTexts.length - 1) {
          setTimeout(onComplete, 1200);
        }
      }, (index + 1) * 800);
    });

    return () => intervals.forEach(clearTimeout);
  }, []);

  return (
    <div className="fixed inset-0 bg-black z-[9999] flex flex-col justify-center items-center font-mono p-4">
      <div className="text-center mb-10">
        <h1 className="text-[#ff4500] uppercase tracking-[0.3em] m-0 text-xl md:text-3xl font-black drop-shadow-[0_0_10px_#ff4500]">
          A NOVA ERA DA PIRATARIA
        </h1>
        <div className="w-full h-[2px] bg-[#ff4500] mt-2 shadow-[0_0_10px_#ff4500]"></div>
      </div>

      <div className="w-[300px] text-[#0f0] text-sm text-left h-32">
        <AnimatePresence>
          {logs.map((index) => (
            <motion.p
              key={index}
              initial={{ opacity: 0, x: -5 }}
              animate={{ opacity: 1, x: 0 }}
              className="my-1"
            >
              {logTexts[index]}
            </motion.p>
          ))}
        </AnimatePresence>
      </div>

      <div className="w-[300px] h-2 bg-[#222] mt-6 border border-[#ff4500]/30 relative overflow-hidden">
        <motion.div
          className="h-full bg-[#ff4500] shadow-[0_0_15px_#ff4500]"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.5 }}
        />
      </div>
      
      {/* Scanlines Effect */}
      <div className="absolute inset-0 pointer-events-none opacity-10 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_4px,3px_100%]"></div>
    </div>
  );
}
