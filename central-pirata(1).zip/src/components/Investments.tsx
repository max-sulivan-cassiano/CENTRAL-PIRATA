import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { 
  TrendingUp, 
  ArrowUpRight, 
  Wallet,
  Plus,
  Target
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';

interface Asset {
  id: string;
  ativo: string;
  categoria: string;
  valorAplicado: number;
  rentabilidade: number;
  progresso: number;
}

const PRICE_HISTORY = [
  { day: '01', price: 10.15 },
  { day: '05', price: 10.32 },
  { day: '10', price: 10.28 },
  { day: '15', price: 10.45 },
  { day: '20', price: 10.38 },
  { day: '25', price: 10.51 },
];

export default function Investments() {
  const [assets, setAssets] = useState<Asset[]>([
    { id: '1', ativo: 'MXRF11', categoria: 'FII', valorAplicado: 12264, rentabilidade: 0.84, progresso: 61 },
    { id: '2', ativo: 'ALZR11', categoria: 'LOGÍSTICA', valorAplicado: 2556, rentabilidade: 0.75, progresso: 15 }
  ]);

  const stats = useMemo(() => {
    const total = assets.reduce((sum, a) => sum + (a.valorAplicado || 0), 0);
    const avgYield = assets.length > 0 
      ? assets.reduce((sum, a) => sum + (a.rentabilidade || 0), 0) / assets.length 
      : 0;
    return { total, avgYield };
  }, [assets]);

  const addAsset = () => {
    setAssets([...assets, { 
      id: Math.random().toString(36).substr(2, 9), 
      ativo: '', 
      categoria: '', 
      valorAplicado: 0, 
      rentabilidade: 0, 
      progresso: 0 
    }]);
  };

  const updateAsset = (id: string, field: keyof Asset, value: any) => {
    setAssets(prev => prev.map(a => a.id === id ? { ...a, [field]: value } : a));
  };

  return (
    <div className="space-y-8 font-mono text-white">
      {/* 2. CARTEIRA E ATIVOS HEADER & SUMMARY */}
      <div className="bg-pm-black p-6 border-2 border-pm-metal shadow-2xl relative">
        <div className="absolute -top-4 left-6 bg-pm-black px-4 border border-pm-metal">
          <h2 className="text-xl md:text-2xl font-black uppercase tracking-widest text-pm-orange flex items-center gap-3">
            <Target size={24} className="text-pm-orange" />
            2. CARTEIRA E ATIVOS
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          <div className="bg-pm-dark/50 p-6 border border-pm-metal flex flex-col items-center justify-center text-center">
            <p className="text-[10px] text-pm-metal font-black uppercase tracking-[0.2em] mb-2 opacity-60">PATRIMÔNIO TOTAL APLICADO</p>
            <h2 className="text-4xl font-black text-white italic tracking-tighter glow-orange">
              R$ {stats.total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </h2>
          </div>
          <div className="bg-pm-dark/50 p-6 border border-pm-metal flex flex-col items-center justify-center text-center">
            <p className="text-[10px] text-pm-metal font-black uppercase tracking-[0.2em] mb-2 opacity-60">RENTABILIDADE MÉDIA MENSAL</p>
            <h2 className="text-4xl font-black text-[#00ff00] italic tracking-tighter glow-green">
              {stats.avgYield.toFixed(2)}%
            </h2>
          </div>
        </div>

        <div className="mt-8 overflow-x-auto">
          <table className="w-full text-left text-[11px] border-collapse min-w-[800px]">
             <thead>
                <tr className="bg-pm-dark/40 uppercase font-black text-pm-orange border-b border-pm-metal">
                  <th className="p-4 border-r border-pm-metal">ATIVO</th>
                  <th className="p-4 border-r border-pm-metal">CATEGORIA</th>
                  <th className="p-4 border-r border-pm-metal">VALOR APLICADO (R$)</th>
                  <th className="p-4 border-r border-pm-metal">RENTAB. (%)</th>
                  <th className="p-4">VALOR ATUAL (EST.)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-pm-metal">
                {assets.map((asset) => {
                  const valorAtual = (asset.valorAplicado || 0) * (1 + (asset.rentabilidade || 0) / 100);
                  return (
                    <tr key={asset.id} className="hover:bg-pm-dark/20 transition-colors">
                      <td className="p-1 border-r border-pm-metal">
                        <input 
                          type="text" 
                          value={asset.ativo}
                          onChange={(e) => updateAsset(asset.id, 'ativo', e.target.value)}
                          placeholder="Ativo..."
                          className="w-full bg-transparent p-3 outline-none focus:bg-pm-black/80 font-black text-white italic uppercase placeholder:text-white/5"
                        />
                      </td>
                      <td className="p-1 border-r border-pm-metal">
                        <input 
                          type="text" 
                          value={asset.categoria}
                          onChange={(e) => updateAsset(asset.id, 'categoria', e.target.value)}
                          placeholder="FII..."
                          className="w-full bg-transparent p-3 outline-none focus:bg-pm-black/80 font-bold text-pm-orange uppercase placeholder:text-white/5"
                        />
                      </td>
                      <td className="p-1 border-r border-pm-metal text-center">
                        <input 
                          type="number" 
                          value={asset.valorAplicado || ''}
                          onChange={(e) => updateAsset(asset.id, 'valorAplicado', Number(e.target.value))}
                          placeholder="0.00"
                          className="w-full bg-transparent p-3 outline-none focus:bg-pm-black/80 font-mono italic text-white placeholder:text-white/5"
                        />
                      </td>
                      <td className="p-1 border-r border-pm-metal">
                        <input 
                          type="number" 
                          value={asset.rentabilidade || ''}
                          onChange={(e) => updateAsset(asset.id, 'rentabilidade', Number(e.target.value))}
                          step="0.01"
                          placeholder="0.00"
                          className="w-full bg-transparent p-3 outline-none focus:bg-pm-black/80 font-mono italic text-[#00ff00] placeholder:text-white/5"
                        />
                      </td>
                      <td className="p-4 font-black text-[#00ff00] italic text-right bg-pm-dark/20 text-lg glow-green">
                        R$ {valorAtual.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
          </table>
        </div>

        <div className="mt-8">
           <div className="flex justify-between items-center mb-3">
              <p className="text-[10px] text-pm-metal font-black uppercase tracking-widest opacity-60">
                RELATÓRIO DE PROVENTOS ESTIMADOS (DISTRIBUIÇÃO)
              </p>
              <button 
                onClick={addAsset}
                className="px-3 py-1 bg-pm-metal/30 hover:bg-pm-orange hover:text-black transition-all text-[9px] font-black uppercase tracking-widest flex items-center gap-2 border border-pm-metal/50"
              >
                <Plus size={12} /> ADICIONAR ATIVO
              </button>
           </div>
           
           <div className="w-full h-10 bg-pm-dark border border-pm-metal flex overflow-hidden">
              {assets.map((asset, idx) => {
                const width = stats.total > 0 ? ((asset.valorAplicado || 0) / stats.total) * 100 : 0;
                const colors = ['bg-pm-orange', 'bg-white', 'bg-pm-fire', 'bg-[#00ff00]', 'bg-pm-metal'];
                if (width === 0) return null;
                return (
                  <motion.div 
                    key={asset.id}
                    initial={{ width: 0 }}
                    animate={{ width: `${width}%` }}
                    className={`${colors[idx % colors.length]} h-full relative group cursor-help`}
                    title={`${asset.ativo}: ${width.toFixed(1)}%`}
                  >
                    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 bg-white/20 transition-opacity" />
                  </motion.div>
                );
              })}
           </div>

           <div className="flex flex-wrap gap-4 mt-3">
              {assets.map((asset, idx) => {
                 const colors = ['text-pm-orange', 'text-white', 'text-pm-fire', 'text-[#00ff00]', 'text-pm-metal'];
                 if (!asset.ativo) return null;
                 return (
                   <span key={asset.id} className="flex items-center gap-2 text-[10px] font-black uppercase italic opacity-80">
                     <span className={`w-2 h-2 ${colors[idx % colors.length].replace('text-', 'bg-')}`} />
                     {asset.ativo}
                   </span>
                 );
              })}
           </div>
        </div>
      </div>
    </div>
  );
}
