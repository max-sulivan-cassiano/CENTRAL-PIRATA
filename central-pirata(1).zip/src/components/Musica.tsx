import React, { useState } from 'react';
import { Music, Plus, Music2 } from 'lucide-react';
import { motion } from 'motion/react';

interface Track {
  id: string;
  nome: string;
  genero: string;
  plataforma: string;
  link: string;
  isOnline: boolean;
}

export default function Musica() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isNightdrive, setIsNightdrive] = useState(false);
  const [volume, setVolume] = useState(85);
  const [tracks, setTracks] = useState<Track[]>([
    { 
      id: '1', 
      nome: '💀 PIRATARIA _MODERNA 💀', 
      genero: 'PHONK / TRAP CYBER', 
      plataforma: 'Spotify', 
      link: '[LINK]',
      isOnline: true
    }
  ]);

  const [activeTrack, setActiveTrack] = useState(tracks[0].nome);

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
    console.log(`Pirataria Moderna: Audio Stream ${!isPlaying ? 'Started' : 'Paused'}.`);
  };

  const toggleNightdrive = () => {
    setIsNightdrive(!isNightdrive);
    setVolume(isNightdrive ? 85 : 100);
    alert(`MODO NIGHTDRIVE ${!isNightdrive ? 'ATIVADO: Graves Reforçados' : 'DESATIVADO'}.`);
  };

  const abrirSpotify = () => {
    alert("Conectando ao terminal Spotify...");
  };

  const adicionarPlaylist = () => {
    const newTrack: Track = {
      id: Math.random().toString(36).substr(2, 9),
      nome: '',
      genero: '',
      plataforma: '',
      link: '',
      isOnline: false
    };
    setTracks([...tracks, newTrack]);
  };

  const updateTrack = (id: string, field: keyof Track, value: any) => {
    setTracks(prev => prev.map(t => {
      if (t.id === id) {
        const updated = { ...t, [field]: value };
        return updated;
      }
      return t;
    }));
  };

  return (
    <div className={`space-y-6 font-mono text-white p-4 border border-pm-metal transition-all duration-700 ${isNightdrive ? 'bg-pm-black shadow-[inset_0_0_100px_rgba(255,69,0,0.1)]' : 'bg-pm-black'}`}>
      <div className="flex items-center justify-between mb-4 border-b-2 border-pm-orange pb-3">
        <h2 className="text-xl font-black uppercase tracking-widest text-pm-orange flex items-center gap-3">
          5. MÚSICA
        </h2>
        <button 
          onClick={adicionarPlaylist}
          className="bg-pm-orange text-black border-none px-4 py-1.5 font-bold cursor-pointer hover:bg-pm-fire transition-colors text-xs flex items-center gap-2"
        >
          <Plus size={14} /> NOVA PLAYLIST
        </button>
      </div>

      <div className="bg-pm-black border border-pm-metal p-1 overflow-x-auto">
        <table className="w-full text-left text-[11px] border-collapse min-w-[700px]">
          <thead>
            <tr className="bg-pm-dark/40 uppercase font-bold text-pm-orange border-b border-pm-metal text-xs">
              <th className="p-3 border border-pm-metal/30">PLAYLIST / FAIXA</th>
              <th className="p-3 border border-pm-metal/30 w-24">STATUS</th>
              <th className="p-3 border border-pm-metal/30">PLATAFORMA</th>
              <th className="p-3 border border-pm-metal/30">LINK</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-pm-metal">
            {tracks.map((track) => (
              <tr key={track.id} className="hover:bg-pm-dark/30 transition-colors">
                <td className="p-1 border border-pm-metal/30">
                  <input 
                    type="text" 
                    value={track.nome}
                    onChange={(e) => {
                      updateTrack(track.id, 'nome', e.target.value);
                      setActiveTrack(e.target.value);
                    }}
                    onFocus={() => setActiveTrack(track.nome)}
                    placeholder="Nova Playlist..."
                    className="w-full bg-transparent p-3 outline-none focus:bg-pm-black/80 placeholder:text-white/10 uppercase italic text-[1em]"
                  />
                </td>
                <td className={`p-3 font-black tracking-widest text-center ${track.isOnline ? 'text-[#00ff00]' : 'text-white/20'}`}>
                  {track.isOnline ? 'ONLINE' : 'OFFLINE'}
                </td>
                <td className="p-1 border border-pm-metal/30">
                  <input 
                    type="text" 
                    value={track.plataforma}
                    onChange={(e) => updateTrack(track.id, 'plataforma', e.target.value)}
                    placeholder="Spotify"
                    className="w-full bg-transparent p-3 outline-none focus:bg-pm-black/80 placeholder:text-white/10 italic text-[1em]"
                  />
                </td>
                <td className="p-1 border border-pm-metal/30">
                  <input 
                    type="text" 
                    value={track.link}
                    onChange={(e) => updateTrack(track.id, 'link', e.target.value)}
                    placeholder="URL"
                    className="w-full bg-transparent p-3 outline-none focus:bg-pm-black/80 placeholder:text-white/10 italic text-[1em]"
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="bg-gradient-to-r from-pm-dark to-pm-black border border-pm-metal p-6 flex items-center gap-6 mt-8 shadow-inner shadow-pm-orange/5">
        <motion.div 
          animate={isPlaying ? { scale: [1, 1.2, 1], opacity: [0.7, 1, 0.7] } : {}}
          transition={isPlaying ? { duration: 2, repeat: Infinity, ease: "easeInOut" } : {}}
          className="text-pm-orange drop-shadow-[0_0_8px_#FF5E00]"
        >
          <Music2 size={48} />
        </motion.div>
        <div className="flex-1">
          <p className="m-0 text-[0.8em] text-pm-metal uppercase font-black tracking-widest italic opacity-50">AGORA TOCANDO:</p>
          <h3 className="m-5 md:m-0 text-xl font-bold text-white letter-spacing-[2px] uppercase italic tracking-widest glow-orange py-1">
            {activeTrack || "SILÊNCIO OPERACIONAL"}
          </h3>
          <div className="w-[250px] h-[3px] bg-pm-metal/30 relative overflow-hidden mt-3 border border-pm-metal/10">
            <motion.div 
              animate={isPlaying ? { x: ["-100%", "100%"] } : { x: "-40%" }}
              transition={isPlaying ? { duration: 5, repeat: Infinity, ease: "linear" } : {}}
              className="w-full h-full bg-pm-orange absolute top-0"
            />
          </div>
        </div>
      </div>

      <div className="mt-8 pt-4 border-t border-pm-metal/30 flex flex-wrap gap-4 text-[0.75em] font-black text-pm-orange uppercase tracking-widest items-center">
        <button 
          onClick={togglePlay}
          className="px-3 py-1 border border-pm-orange hover:bg-pm-orange hover:text-black transition-all"
        >
          [F1] {isPlaying ? 'PAUSE' : 'PLAY'}
        </button>
        <button 
          onClick={toggleNightdrive}
          className="px-3 py-1 border border-pm-orange hover:bg-pm-orange hover:text-black transition-all"
        >
          [F2] {isNightdrive ? 'MODO NORMAL' : 'MODO NIGHTDRIVE'}
        </button>
        <button 
          onClick={abrirSpotify}
          className="px-3 py-1 border border-pm-orange hover:bg-pm-orange hover:text-black transition-all"
        >
          [F3] ABRIR NO SPOTIFY
        </button>
        
        <div className="ml-auto flex items-center gap-4">
          <span className="text-[#00ff00]">VOL: {volume}% | ENCRYPTED_STREAM</span>
          <span className="text-pm-fire animate-pulse font-mono shadow-pm-fire/20 border-l border-pm-metal/30 pl-4 opacity-60">PIRATARIA_MODERNA_REDE_CONECTADA</span>
        </div>
      </div>
    </div>
  );
}
